#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from MyQR.QRCode import run
import os

def start_qrcode():
    # 开启键盘输入信息
    print("\033[32m 欢迎使用二维码生成程序 \033[0m\n")

    # 接收二维码内容信息
    content = input("Step-01: 生成程序开始，请输入您的信息：\n")

    # 定制化提示
    flag = input("\033[32mStep-02: 是否启用自定义参数？\033[0m\n"
                 "\t1、版本：[1 - 40]\n"
                 "\t2、容错质量 Error-Correction-Level：[L(Low), M(Medium) or Q(Quartile), H(High)]\n"
                 "\t3、背景图片：[None or 图片路径]\n"
                 "\t4、彩色背景：[True or False]\n"
                 "\t5、对比度：（浮点数）\n"
                 "\t6、亮暗程度：（浮点数）\n"
                 "\t7、保存名称：（支持*.gif, *.png, *.jpg）\n"
                 "\t8、保存路径：\n"
                 "\t\033[31m 是否启动自定义：[ True or  False ] \033[0m\n")
    # 是否定制化
    if flag.strip() == "True":
        print("\n二维码定制化开始.....\n")
        version = input("【定制-1/8】QRCode 版本选择：[1 ~ 40]\n")
        level = input("【定制-2/8】容错级别: [L , M, Q, H]\n")
        picture = input("【定制-3/8】背景图片：[None or 图片路径 /opt/<>/aa.png]\n")
        colorized = input("【定制-4/8】彩色背景：[True/ False]\n")
        contrast = input("【定制-5/8】对比度：（float）\n")
        brightness = input("【定制-6/8】明亮程度：（float）\n")
        output_name = input("【定制-7/8】二维码保存名称：[.gif, *.jpg, *.png]\n")
        directory = input("【定制-8/8】二维码保存路径\n")

        # 待完善，如何校验输入值（是否有效）？
        # [1/8]-版本范围

        # [2/8]-容错级别

        # .....

        # [4/8]- 处理背景图片
        if picture.strip() == "" or picture == "None":
            picture = None
        else:
            # 确认图片可用
            if not os.path.exists(picture):
                raise BaseException(picture+"图片资源不存在")

        # ....
    else:
        print("\n使用默认参数，执行二维码生成\n")
        version = 1
        level = "H"
        picture = None
        colorized = False
        contrast = 1.0
        brightness = 1.0
        output_name = "qrcode.png"
        directory = os.getcwd()

    # 获取输入值，进行生成对应的二维码
    try:
        ver, ecl, qr_name = run(
            # 二维码内容
            content,
            # 二维码版本
            int(version),
            # 容错级别
            level,
            # 背景图片
            picture,
            # 是否彩色
            bool(colorized),
            # 对比度
            float(contrast),
            # 明亮程度
            float(brightness),
            # 二维码图片名称
            output_name,
            # 生成目录
            directory
            )

        print('QRCode Generate Process Succeed! \n Check out your', str(ver) + '-' + str(ecl), 'QR-code Path is :', qr_name)
        print("")

        # 图片打开
        from PIL import Image
        im = Image.open(qr_name)
        im.show()

    except Exception:
        raise Exception("QRCode 生成过程出错，请校验过程")