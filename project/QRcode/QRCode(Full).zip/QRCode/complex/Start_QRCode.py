# -*- coding: utf-8 -*-

from MyQR.Trigger_QRcode import start_qrcode

if __name__ == '__main__':
    start_qrcode()